/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoImpl;

import dao.StockDao;
import dao.dbHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modul.Stock;
import swing.StockSw;

/**
 *
 * @author nur13
 */
public class StockDaoImpl extends dbHelper implements StockDao{

    @Override
    public List<Stock> getAllStock() {
        List<Stock> result = new ArrayList<>();
        try (Connection c = connect()) {
            PreparedStatement p = c.prepareStatement("SELECT * FROM STOCK_TAB");
            ResultSet rs = p.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String symbol = rs.getString("SYMBOL");
                String company = rs.getString("COMPANY");
               
                Stock s=new Stock(id, symbol, company);
                result.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
    }

    



   
    

