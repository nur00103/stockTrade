/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoImpl;

import dao.StockDao;
import dao.StockPriceDao;
import dao.dbHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modul.Stock;
import modul.StockPrice;

/**
 *
 * @author nur13
 */
public class StockPriceDaoImpl  extends dbHelper implements StockPriceDao{

    @Override
    public List<StockPrice> getAllStockPrice() {
        List<StockPrice> result = new ArrayList<>();
        try (Connection c = connect()) {
            PreparedStatement p = c.prepareStatement("SELECT * FROM STOCK_PRICE SP\n" +
"LEFT JOIN STOCK_TAB  S ON SP.STOCK_ID=S.ID");
            ResultSet rs = p.executeQuery();
            while (rs.next()) {
                int StockPriceId = rs.getInt("ID");
                String dateStock=rs.getString("DATE_STOCK");
                String open = rs.getString("OPEN");
                String high = rs.getString("HIGH");
                String low = rs.getString("LOW");
                String close = rs.getString("CLOSE");
                String volume = rs.getString("VOLUME");
                int stockId = rs.getInt("STOCK_ID");
                String symbol = rs.getString("SYMBOL");
                String company = rs.getString("COMPANY");
               
                Stock stock=new Stock(stockId, symbol, company);
                StockPrice stockPrice=new StockPrice(stockId, stock, close, open, high, low, close, volume);
                 result.add(stockPrice);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
    }

    
    

