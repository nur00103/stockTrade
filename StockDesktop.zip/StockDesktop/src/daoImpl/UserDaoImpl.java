/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoImpl;

import dao.UserDao;
import dao.dbHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modul.User;

/**
 *
 * @author nur13
 */
public class UserDaoImpl extends dbHelper implements UserDao {

    @Override
    public List<User> getAllUser() {
        List<User> result = new ArrayList<>();
        try (Connection c = connect()) {
            PreparedStatement p = c.prepareStatement("SELECT * FROM USER_TAB");
            ResultSet rs = p.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("NAME");
                String surname = rs.getString("SURNAME");
                String username = rs.getString("USERNAME");
                String password = rs.getString("PASSWORD");
                String email = rs.getString("EMAIL");
                String position = rs.getString("POSITION");

                User user = new User(id, username, name, surname, email, password, position);
                result.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    @Override
    public User getUserById(int customerId) {
        User result = null;
        try (Connection connection = connect()) {

            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM USER_TAB WHERE ID=" + customerId);
            while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("NAME");
                String surname = rs.getString("SURNAME");
                String username = rs.getString("USERNAME");
                String password = rs.getString("PASSWORD");
                String email = rs.getString("EMAIL");
                String position = rs.getString("POSITION");

                User user = new User(id, username, name, surname, email, password, position);
                result = user;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public boolean updateUser(User c) {
        try (Connection cn = connect()) {
            PreparedStatement p = cn.prepareStatement("UPDATE USER_TAB SET ID=?,USERNAME=?,NAME=?,SURNAME=?,EMAIL=?,PASSWORD=?,POSITION=? WHERE ID=?");
            p.setInt(1, c.getId());
            p.setString(2, c.getUsername());
            p.setString(3, c.getName());
            p.setString(4, c.getSurname());
            p.setString(5, c.getEmail());
            p.setString(6, c.getPassword());
            p.setString(7, c.getPosition());
            p.setInt(8, c.getId());
            return p.execute();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean addUser(User c) {
        try (Connection cn = connect()) {
            PreparedStatement p = cn.prepareStatement("INSERT INTO USER_TAB(ID,USERNAME,NAME,SURNAME,EMAIL,PASSWORD,POSITION) "
                    + "VALUES(USER_S.NEXTVAL,?,?,?,?,?,?)");
            
            p.setString(1, c.getUsername());
            p.setString(2, c.getName());
            p.setString(3, c.getSurname());
            p.setString(4, c.getEmail());
            p.setString(5, c.getPassword());
            p.setString(6, c.getPosition());
            return p.execute();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean removeUser(int id) {
        try (Connection c = connect()) {
            Statement stmt = c.createStatement();
            return stmt.execute("DELETE FROM USER_TAB WHERE ID=" + id);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<User> searchUserData(String text) {
        List<User> result = new ArrayList<>();
        try (Connection c = connect()) {
            PreparedStatement p = c.prepareStatement("SELECT * FROM USER_TAB WHERE ACTIVE=1 AND LOWER(NAME) LIKE LOWER(?) OR LOWER(SURNAME) LIKE LOWER(?) OR LOWER(USERNAME) LIKE LOWER(?)");
            p.setString(1, '%' + text + '%');
            p.setString(2, '%' + text + '%');
            p.setString(3, '%' + text + '%');
            ResultSet rs = p.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("NAME");
                String surname = rs.getString("SURNAME");
                String username = rs.getString("USERNAME");
                String password = rs.getString("PASSWORD");
                String email = rs.getString("EMAIL");
                String position = rs.getString("POSITION");

                User user = new User(id, username, name, surname, email, password, position);

                result.add(user);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

}
