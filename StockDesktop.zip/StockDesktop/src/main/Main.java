/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import dao.StockDao;
import dao.StockPriceDao;
import dao.UserDao;
import daoImpl.StockDaoImpl;
import daoImpl.StockPriceDaoImpl;
import daoImpl.UserDaoImpl;
import swing.MainSw;

/**
 *
 * @author nur13
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try{
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            UserDao c=new UserDaoImpl();
            StockDao sd =new StockDaoImpl();
            StockPriceDao spd=new StockPriceDaoImpl();
            
            MainSw mainFrame=new MainSw(c,sd,spd);
            mainFrame.setVisible(true);
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
}
