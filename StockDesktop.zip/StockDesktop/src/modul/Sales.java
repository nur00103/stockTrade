/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul;

/**
 *
 * @author nur13
 */
public class Sales {
    private int id;
    private User user;
    private Stock stock;
    private int quantity;
    private int amount;

    public Sales() {
    }

    public Sales(int id, User user, Stock stock, int quantity, int amount) {
        this.id = id;
        this.user = user;
        this.stock = stock;
        this.quantity = quantity;
        this.amount = amount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Stock getStock() {
        return stock;
    }

    public void setStock(Stock stock) {
        this.stock = stock;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Sales{" + "id=" + id + ", user=" + user + ", stock=" + stock + ", quantity=" + quantity + ", amount=" + amount + '}';
    }
    
    
}
