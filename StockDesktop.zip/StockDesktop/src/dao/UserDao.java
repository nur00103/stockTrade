/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import modul.User;

/**
 *
 * @author nur13
 */
public interface UserDao {
    
    public List<User> getAllUser();
    
    public User getUserById(int id);
    
    public boolean updateUser(User u);
    
    public boolean addUser(User c);
    
    public boolean removeUser (int id);
    
    public List<User> searchUserData (String text);
}
