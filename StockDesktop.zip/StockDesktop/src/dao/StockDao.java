/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import modul.Stock;
import swing.StockSw;

/**
 *
 * @author nur13
 */
public interface StockDao {
    
    public List<Stock> getAllStock();
}
