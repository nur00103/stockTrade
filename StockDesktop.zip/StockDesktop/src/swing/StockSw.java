/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swing;

import dao.StockDao;
import dao.StockPriceDao;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import modul.StockPrice;

/**
 *
 * @author nur13
 */
public class StockSw extends javax.swing.JFrame {
     private StockPriceDao spd;
     private StockPrice sp;
     private StockDao sd;
    /**
     * Creates new form Stock
     */
    public StockSw() {
        initComponents();
    }

    public StockSw(StockPriceDao spd, StockDao sd) {
                initComponents();
                this.spd=spd;
                this.sd=sd;

    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        allstock = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        allstock.setText("ALL STOCK");
        allstock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                allstockActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 763, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(allstock, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(allstock, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void allstockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_allstockActionPerformed
        try{
        DefaultTableModel model=new DefaultTableModel();
        jTable1.setModel(model);
        model.addColumn("ID");
        model.addColumn("Symbol");
        model.addColumn("Company");
        model.addColumn("Date");
        model.addColumn("Open");
        model.addColumn("High");
        model.addColumn("Low");
        model.addColumn("Close");
        model.addColumn("Volume");
        

        
        for (StockPrice sp :spd.getAllStockPrice()) {
            Object [] data=new Object[]{
                sp.getId(),sp.getStock().getSymbol(),sp.getStock().getCompany(),sp.getDate(),sp.getOpen(),sp.getHigh(),sp.getLow(),sp.getClose(),sp.getVolume()
            };
            model.addRow(data);
        }
        model.fireTableDataChanged();
         }
        catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_allstockActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton allstock;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
